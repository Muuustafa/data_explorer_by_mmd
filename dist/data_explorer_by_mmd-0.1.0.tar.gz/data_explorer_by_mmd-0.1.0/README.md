# Data Explorer

Un package Python pour explorer les données économiques de la Banque Mondiale.

## Installation

```bash
pip install data_explorer
```
